# SaintSal Schema

This repository contains the OpenAPI schema for the SaintSal Core Agent v1.